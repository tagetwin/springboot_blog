package com.yndg.blog.model.user.dto;

import lombok.Data;

@Data
public class ReqProfileDto {
	
	private int id;
	private String password;
	private String profile;
	
}
