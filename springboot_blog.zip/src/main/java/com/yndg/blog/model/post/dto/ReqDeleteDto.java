package com.yndg.blog.model.post.dto;

import lombok.Data;

@Data
public class ReqDeleteDto {
	
	private int id;
	private int userId;
}
